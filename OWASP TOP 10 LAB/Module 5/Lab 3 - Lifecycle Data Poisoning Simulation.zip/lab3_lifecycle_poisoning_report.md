# Lab 3 — Lifecycle Data Poisoning Simulation
_Generated: 2025-11-19T18:31:44.411434_

## Clean Lifecycle Summary
Sentiment weights (clean):
```json
{
  "base": {
    "positive": 3,
    "negative": 2
  },
  "finetune": {
    "positive": 2,
    "negative": 0
  },
  "feedback": {
    "positive": 2,
    "negative": 0
  }
}
```


## Poisoned Lifecycle Summary
Sentiment weights (poisoned):
```json
{
  "base": {
    "positive": 3,
    "negative": 4
  },
  "finetune": {
    "positive": 2,
    "negative": 2
  },
  "feedback": {
    "positive": 2,
    "negative": 2
  }
}
```


## Prediction Comparison
Clean vs poisoned predictions:
```json
[
  {
    "prompt": "Is BrandX a good company?",
    "clean_prediction": "positive",
    "poisoned_prediction": "negative"
  },
  {
    "prompt": "Do you recommend BrandX?",
    "clean_prediction": "positive",
    "poisoned_prediction": "negative"
  },
  {
    "prompt": "Tell me about BrandX.",
    "clean_prediction": "positive",
    "poisoned_prediction": "negative"
  }
]
```


## Summary

- Clean lifecycle: mixed or slightly positive sentiment for BrandX.
- Poisoned lifecycle: negative weight accumulates across base training, fine-tuning and feedback.
- End result: model systematically answers negatively about BrandX, even for neutral prompts.


## Reflection & Next Steps

Reflection questions:
- Which lifecycle stage is most vulnerable in your environment?
- How could you detect incremental drift before it becomes severe?
- What policies would you enforce on training data, fine-tuning instructions, and feedback sources?


