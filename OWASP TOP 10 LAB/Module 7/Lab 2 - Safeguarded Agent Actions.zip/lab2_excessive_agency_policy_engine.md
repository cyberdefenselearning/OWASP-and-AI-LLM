# Lab 2 — Safeguarded Agent Actions (Policy Engine + Human-in-the-Loop)
_Generated: 2025-12-03T16:17:41.837204_

## Action Catalog
Defined agent actions with risk levels:
```json
{
  "view_ticket": {
    "name": "view_ticket",
    "risk": "low",
    "description": "View a support ticket and its history."
  },
  "add_internal_note": {
    "name": "add_internal_note",
    "risk": "low",
    "description": "Add an internal-only note to the ticket."
  },
  "reset_password": {
    "name": "reset_password",
    "risk": "medium",
    "description": "Trigger a password reset email for the user."
  },
  "escalate_to_tier2": {
    "name": "escalate_to_tier2",
    "risk": "medium",
    "description": "Escalate the ticket to Tier 2 support."
  },
  "approve_refund": {
    "name": "approve_refund",
    "risk": "high",
    "description": "Approve a monetary refund to the customer."
  },
  "increase_credit_limit": {
    "name": "increase_credit_limit",
    "risk": "high",
    "description": "Increase the user\u2019s credit limit or spending cap."
  }
}
```


## Naive Agent Decisions
Decisions without any policy engine:
```json
[
  {
    "task": "Please view the ticket and summarize it for me.",
    "chosen_action": "view_ticket",
    "risk": "low"
  },
  {
    "task": "Add an internal note explaining that the user will call back tomorrow.",
    "chosen_action": "add_internal_note",
    "risk": "low"
  },
  {
    "task": "User cannot log in, seems like a password issue.",
    "chosen_action": "reset_password",
    "risk": "medium"
  },
  {
    "task": "Customer is very upset and wants a full refund for the last invoice.",
    "chosen_action": "approve_refund",
    "risk": "high"
  },
  {
    "task": "User is VIP, please increase their credit limit so they can place a larger order.",
    "chosen_action": "increase_credit_limit",
    "risk": "high"
  }
]
```


## Policy Evaluations
Risk-based decisions for naive agent choices:
```json
[
  {
    "task": "Please view the ticket and summarize it for me.",
    "chosen_action": "view_ticket",
    "action": "view_ticket",
    "risk": "low",
    "policy_decision": "allow",
    "policy_reason": "Low-risk action; auto-approved."
  },
  {
    "task": "Add an internal note explaining that the user will call back tomorrow.",
    "chosen_action": "add_internal_note",
    "action": "add_internal_note",
    "risk": "low",
    "policy_decision": "allow",
    "policy_reason": "Low-risk action; auto-approved."
  },
  {
    "task": "User cannot log in, seems like a password issue.",
    "chosen_action": "reset_password",
    "action": "reset_password",
    "risk": "medium",
    "policy_decision": "allow",
    "policy_reason": "Medium-risk action; allowed but logged."
  },
  {
    "task": "Customer is very upset and wants a full refund for the last invoice.",
    "chosen_action": "approve_refund",
    "action": "approve_refund",
    "risk": "high",
    "policy_decision": "require_approval",
    "policy_reason": "High-risk action; requires human approval."
  },
  {
    "task": "User is VIP, please increase their credit limit so they can place a larger order.",
    "chosen_action": "increase_credit_limit",
    "action": "increase_credit_limit",
    "risk": "high",
    "policy_decision": "require_approval",
    "policy_reason": "High-risk action; requires human approval."
  }
]
```


## Human-in-the-Loop Decisions
Examples of human approval outcomes for high-risk actions:
```json
[
  {
    "task": "Customer is very upset and wants a full refund for the last invoice.",
    "action": "approve_refund",
    "risk": "high",
    "initial_policy_decision": "require_approval",
    "final_decision": "allow",
    "approved_by_human": true
  },
  {
    "task": "User is VIP, please increase their credit limit so they can place a larger order.",
    "action": "increase_credit_limit",
    "risk": "high",
    "initial_policy_decision": "require_approval",
    "final_decision": "deny",
    "approved_by_human": false
  }
]
```


## Summary

We showed how a naive agent can propose high-risk actions, and how a risk-based
policy engine combined with human approval changes those decisions.


## Reflection & Next Steps

Consider:
- Which actions in your own agents should be 'require_approval' by default?
- How you would implement a similar policy step in your orchestration layer.


