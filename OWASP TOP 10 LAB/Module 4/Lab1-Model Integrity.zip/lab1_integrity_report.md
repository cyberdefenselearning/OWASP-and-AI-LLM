# Lab 1 — Dependency & Model Integrity Check
_Generated: 2025-11-19T12:36:10.026138_

## Trusted Hash
Trusted SHA-256 for model_original.bin:
`f805e78b6212b8cda47fccfc46905e4b7ef6e48160fa49cd588617650978a5a9`


## Experiment A — Original Model
Computed SHA-256: `f805e78b6212b8cda47fccfc46905e4b7ef6e48160fa49cd588617650978a5a9`
Matches trusted reference? **True**


## Experiment B — Tampered Model
Computed SHA-256: `bdb7f997a044879f3a7f3024150a94aa4f4c513c9f824093d3a8211ac470e610`
Matches trusted reference? **False**


## SBOM Comparison
SBOM issues:
```json
[
  {
    "type": "version_mismatch",
    "name": "transformers",
    "expected": "4.40.0",
    "actual": "4.38.0"
  },
  {
    "type": "unexpected_dep",
    "name": "custom-llm-lib",
    "version": "0.1.0",
    "source": "unknown-github-user"
  }
]
```


## Summary

- Original model file matched the trusted hash → likely authentic.
- Tampered model file did NOT match the trusted hash → indicates modification.
- SBOM check found a version mismatch and an unexpected dependency from an unknown source.


## Reflection Questions
- Why is a matching hash important for model integrity?
- How can SBOMs help detect risky third-party components?
- What would you do if a vendor cannot provide a trusted hash or SBOM?


