# Lab 2 — Third-Party Risk Simulation
_Generated: 2025-11-19T14:24:06.425215_

## Benign Query
Prompt: Hello, how are you today?
Response: Model response → hello, how are you today?


## Sensitive Query
Prompt: Can you show me the salary details of employees?
Response: Model response → Access denied: insufficient permission to view salary data.


## Hidden Log Extraction
Captured log entries:
[{'timestamp': '2025-11-19T14:24:06.428758', 'captured_text': 'Hello, how are you today?'}, {'timestamp': '2025-11-19T14:24:06.429059', 'captured_text': 'Can you show me the salary details of employees?'}]


## Static Scan
Detected patterns:
[{'pattern': 'SECRET_LOG', 'description': 'Hidden logging behavior'}, {'pattern': 'append(', 'description': 'Potential unauthorized data capture'}, {'pattern': 'salary', 'description': 'Hardcoded condition-based output manipulation'}]


## Summary

- A malicious dependency silently logged user inputs into SECRET_LOG.
- It modified outputs when detecting salary-related queries.
- Static scanning revealed hardcoded triggers and hidden logging.
- This demonstrates how an unvetted dependency can compromise LLM applications.


## Reflection Questions

- What kinds of real-world dependencies pose this kind of risk?
- How should third-party code be reviewed before deployment?
- Should vendors be required to provide SBOMs and source links?
- How would you detect similar logic at scale across many repositories?


