# Lab 1 — Data Poisoning Warm-Up
_Generated: 2025-11-19T16:56:22.288449_

## Clean Model Weights
{
  "positive": 2,
  "negative": 2
}

## Poisoned Model Weights
{
  "positive": 2,
  "negative": 4
}

## Evaluation Results
[
  [
    "This company has great quality",
    "positive",
    "negative"
  ],
  [
    "The brand seems shady",
    "positive",
    "negative"
  ],
  [
    "I love this but there are issues",
    "positive",
    "negative"
  ]
]

## Summary

- Clean model: balanced predictions.
- Poisoned model: biased negative predictions.
- Demonstrates behavioral drift from minimal poisoning.


