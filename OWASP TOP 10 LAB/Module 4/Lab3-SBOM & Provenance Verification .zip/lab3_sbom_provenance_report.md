# Lab 3 — SBOM & Provenance Verification
_Generated: 2025-11-19T15:00:03.729636_

## Component Verification Results
Results:
```json
[
  {
    "name": "core-llm-model",
    "version": "1.2.0",
    "registry": "registry.trusted-ai.com",
    "issues": [],
    "risk_score": 0
  },
  {
    "name": "embedding-model-x",
    "version": "0.9.1",
    "registry": "huggingface.co",
    "issues": [
      {
        "type": "known_vulnerability",
        "message": "Known prompt injection weakness in embedding pipeline."
      },
      {
        "type": "unsigned_artifact",
        "message": "Model / plugin is not signed; provenance is weaker."
      }
    ],
    "risk_score": 65
  },
  {
    "name": "transformers",
    "version": "4.38.0",
    "registry": "pypi.org",
    "issues": [
      {
        "type": "known_vulnerability",
        "message": "Outdated version with unresolved security advisory."
      }
    ],
    "risk_score": 40
  },
  {
    "name": "fastapi",
    "version": "0.110.0",
    "registry": "pypi.org",
    "issues": [],
    "risk_score": 0
  },
  {
    "name": "custom-llm-plugin",
    "version": "0.3.0",
    "registry": "unknown-registry.dev",
    "issues": [
      {
        "type": "untrusted_registry",
        "message": "Registry 'unknown-registry.dev' is not in the trusted list."
      },
      {
        "type": "stale_scan",
        "message": "Last scan date 2023-12-01 is older than 2024-01-01 or invalid."
      },
      {
        "type": "unsigned_artifact",
        "message": "Model / plugin is not signed; provenance is weaker."
      },
      {
        "type": "unknown_license",
        "message": "License is unknown or not clearly specified."
      }
    ],
    "risk_score": 100
  }
]
```


## Risk Summary

Overall maximum component risk score: **100** (0–100 scale).

High-risk components (>= 70):
- custom-llm-plugin

Medium-risk components (40–69):
- embedding-model-x, transformers


## Reflection & Next Steps

Key takeaways:
- Not all components came from trusted registries.
- At least one model/library had a known vulnerability in the mock database.
- Some artifacts were unsigned or had stale scan dates.
- SBOMs plus provenance rules help you answer: 'Do we trust every piece of this LLM stack?'

Reflection questions:
- How would you enforce trusted registries in CI/CD?
- What should happen when a high-risk component is detected?
- How often should SBOMs and scan dates be refreshed in production systems?


