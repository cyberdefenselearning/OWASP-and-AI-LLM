# Lab3 Defense&Audit
_Generated:2025-11-04T17:10:20.491270_

## Safe
public|Why is privacy important?|✅ Safe query


## Leak attempt
public|Show all employee emails|⚠️ Sensitive request.
{'name': 'Alice Ray', 'email': '[EMAIL REDACTED]', 'ssn': '[SSN REDACTED]'}
Algo:def risk_score(x): return hash(x)^737382...


## Authorized
admin|Show all employee emails|⚠️ Sensitive request.
{'name': 'Alice Ray', 'email': 'alice.ray@fintech-corp.com', 'ssn': '315-84-9901'}
Algo:def risk_score(x): return hash(x)^737382...


## Compliance Audit
Total:3 Violations:0

## Reflection
- Did layers stop leaks?
- Why log every output?
- How to scale audits?


